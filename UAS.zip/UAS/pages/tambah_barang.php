<?php
global $db;

if(isset($_POST['simpan'])){

    $kd_barang   = trim($_POST['kd_barang']);
    $kode_jenis  = trim($_POST['kode_jenis']);
    $nama_barang = trim($_POST['nama_barang']);
    $stok        = $_POST['stok'];
    $harga_beli  = $_POST['harga_beli'];
    $harga_jual  = $_POST['harga_jual'];

    // Cek kode barang sudah ada atau belum
    $cek = $db->query("
        SELECT *
        FROM tb_barang
        WHERE kd_barang='$kd_barang'
    ");

    if(mysqli_num_rows($cek) > 0){

        echo "<div class='alert alert-danger'>
                Kode barang sudah digunakan.
              </div>";

    }else{

        $query = $db->query("
            INSERT INTO tb_barang
            (
                kd_barang,
                kode_jenis,
                nama_barang,
                stok,
                harga_beli,
                harga_jual
            )
            VALUES
            (
                '$kd_barang',
                '$kode_jenis',
                '$nama_barang',
                '$stok',
                '$harga_beli',
                '$harga_jual'
            )
        ");

        if($query){

            echo "<script>
                alert('Data berhasil ditambahkan');
                window.location='?page=barang';
            </script>";

        }else{

            echo "<div class='alert alert-danger'>
                    Gagal menyimpan data.
                  </div>";
        }
    }
}
?>

<div class="card shadow-sm p-4">

    <h3 class="mb-4">Tambah Barang</h3>

    <form method="post">

        <div class="mb-3">
            <label>Kode Barang</label>
            <input type="text"
                   name="kd_barang"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Jenis Barang</label>

            <select name="kode_jenis"
                    class="form-control"
                    required>

                <option value="">
                    -- Pilih Jenis Barang --
                </option>

                <?php

                $jenis = $db->query("
                    SELECT *
                    FROM tb_jenis
                    ORDER BY jenis ASC
                ");

                while($j = mysqli_fetch_assoc($jenis)){
                ?>

                    <option value="<?= $j['kode_jenis']; ?>">
                        <?= $j['jenis']; ?> (<?= $j['satuan']; ?>)
                    </option>

                <?php } ?>

            </select>
        </div>

        <div class="mb-3">
            <label>Nama Barang</label>
            <input type="text"
                   name="nama_barang"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Stok</label>
            <input type="number"
                   name="stok"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Harga Modal</label>
            <input type="number"
                   name="harga_beli"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Harga Jual</label>
            <input type="number"
                   name="harga_jual"
                   class="form-control"
                   required>
        </div>

        <button type="submit"
                name="simpan"
                class="btn btn-success">
            Simpan
        </button>

        <a href="?page=barang"
           class="btn btn-secondary">
            Kembali
        </a>

    </form>

</div>