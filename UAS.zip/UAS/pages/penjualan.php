<?php
global $db;
?>

<div class="card shadow-sm">
    <div class="card-body">

        <h3 class="mb-4">History Transaksi Penjualan</h3>

        <a href="?page=tambah_penjualan"
   class="btn btn-primary mb-3 w-100">
   + Input Penjualan
</a>

        <table class="table table-bordered table-striped">

            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>No Penjualan</th>
                    <th>Tanggal</th>
                    <th>Customer</th>
                    <th>Total Barang</th>
                    <th>Total Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>

            <?php

            $no = 1;

            $data = $db->query("
                SELECT
                    p.*,
                    c.nama_customer
                FROM tb_penjualan p
                LEFT JOIN tb_customer c
                ON p.id_customer = c.id_customer
                ORDER BY p.no_penjualan DESC
            ");

            while($r = mysqli_fetch_assoc($data)){
            ?>

                <tr>

                    <td><?= $no++; ?></td>

                    <td><?= $r['no_penjualan']; ?></td>

                    <td><?= $r['tanggal_penjualan']; ?></td>

                    <td><?= $r['nama_customer']; ?></td>

                    <td><?= $r['total_barangall']; ?></td>

                    <td>
                        Rp <?= number_format($r['total_hargaall'],0,',','.'); ?>
                    </td>

                    <td>

                        <a href="?page=detail_penjualan&id=<?= $r['no_penjualan']; ?>"
                           class="btn btn-info btn-sm">
                            Detail
                        </a>

                    </td>

                </tr>

            <?php } ?>

            </tbody>

        </table>

    </div>
</div>