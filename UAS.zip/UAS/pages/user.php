<?php
global $db;

// Hapus user
if(isset($_GET['hapus'])){
    $id = $_GET['hapus'];

    $db->query("DELETE FROM user WHERE id_user='$id'");

    echo "<script>
        alert('User berhasil dihapus');
        window.location='?page=user';
    </script>";
}
?>

<div class="card shadow-sm p-4">

    <h3>Data Pengguna</h3>

    <a href="?page=tambah_user" class="btn btn-primary mb-3">
        + Tambah User
    </a>

    <table class="table table-bordered table-striped">

        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Username</th>
                <th>Password</th>
                <th>Tipe User</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
        <?php
        $no = 1;
        $data = $db->query("SELECT * FROM user");

        while($r = mysqli_fetch_assoc($data)){
        ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $r['username']; ?></td>
                <td><?= $r['password']; ?></td>
                <td><?= $r['tipe_user']; ?></td>
                <td>
                    <a href="?page=edit_user&id=<?= $r['id_user']; ?>"
                       class="btn btn-warning btn-sm">
                        Edit
                    </a>

                    <a href="?page=user&hapus=<?= $r['id_user']; ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Yakin hapus user?')">
                        Hapus
                    </a>
                </td>
            </tr>
        <?php } ?>
        </tbody>

    </table>

</div>