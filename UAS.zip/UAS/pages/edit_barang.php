<?php
global $db;

$id = $_GET['id'];

$data = $db->query("
    SELECT *
    FROM tb_barang
    WHERE kd_barang='$id'
");

$r = mysqli_fetch_assoc($data);

if(isset($_POST['update'])){

    $kode_jenis  = $_POST['kode_jenis'];
    $nama_barang = $_POST['nama_barang'];
    $stok        = $_POST['stok'];
    $harga_beli  = $_POST['harga_beli'];
    $harga_jual  = $_POST['harga_jual'];

    $query = $db->query("
        UPDATE tb_barang
        SET
            kode_jenis='$kode_jenis',
            nama_barang='$nama_barang',
            stok='$stok',
            harga_beli='$harga_beli',
            harga_jual='$harga_jual'
        WHERE kd_barang='$id'
    ");

    if($query){
        echo "<script>
            alert('Data berhasil diupdate');
            window.location='?page=barang';
        </script>";
    }
}
?>

<div class="card shadow-sm p-4">
    <h3>Edit Barang</h3>

    <form method="post">

        <div class="mb-3">
            <label>Kode Barang</label>
            <input type="text"
                   class="form-control"
                   value="<?= $r['kd_barang']; ?>"
                   readonly>
        </div>

        <div class="mb-3">
            <label>Jenis Barang</label>

            <select name="kode_jenis"
                    class="form-control"
                    required>

                <?php
                $jenis = $db->query("
                    SELECT *
                    FROM tb_jenis
                    ORDER BY jenis
                ");

                while($j = mysqli_fetch_assoc($jenis)){
                ?>
                    <option value="<?= $j['kode_jenis']; ?>"
                        <?= ($j['kode_jenis'] == $r['kode_jenis']) ? 'selected' : ''; ?>>
                        <?= $j['jenis']; ?> (<?= $j['satuan']; ?>)
                    </option>
                <?php } ?>

            </select>
        </div>

        <div class="mb-3">
            <label>Nama Barang</label>
            <input type="text"
                   name="nama_barang"
                   value="<?= $r['nama_barang']; ?>"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Stok</label>
            <input type="number"
                   name="stok"
                   value="<?= $r['stok']; ?>"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Harga Modal</label>
            <input type="number"
                   name="harga_beli"
                   value="<?= $r['harga_beli']; ?>"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Harga Jual</label>
            <input type="number"
                   name="harga_jual"
                   value="<?= $r['harga_jual']; ?>"
                   class="form-control"
                   required>
        </div>

        <button type="submit"
                name="update"
                class="btn btn-primary">
            Update
        </button>

        <a href="?page=barang"
           class="btn btn-secondary">
            Kembali
        </a>

    </form>
</div>