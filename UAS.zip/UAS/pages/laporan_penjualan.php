<?php
global $db;

$tgl_awal  = $_GET['tgl_awal'] ?? '';
$tgl_akhir = $_GET['tgl_akhir'] ?? '';
?>

<div class="card shadow-sm">
    <div class="card-body">

        <h3>Laporan Penjualan</h3>

        <form method="GET" class="row mb-3">

            <input type="hidden" name="page" value="laporan_penjualan">

            <div class="col-md-3">
                <label>Tanggal Awal</label>
                <input type="date"
                       name="tgl_awal"
                       value="<?= $tgl_awal ?>"
                       class="form-control">
            </div>

            <div class="col-md-3">
                <label>Tanggal Akhir</label>
                <input type="date"
                       name="tgl_akhir"
                       value="<?= $tgl_akhir ?>"
                       class="form-control">
            </div>

            <div class="col-md-3 mt-4">
                <button class="btn btn-primary">
                    Tampilkan
                </button>

                <button type="button"
                        onclick="window.print()"
                        class="btn btn-success">
                    Cetak
                </button>
            </div>

        </form>

        <div id="print-area" data-tanggal="<?= date('d-m-Y'); ?>">

            <center>
                <h2>LAPORAN PENJUALAN</h2>

                <?php
                if($tgl_awal && $tgl_akhir){
                    echo "<b>Periode : $tgl_awal s/d $tgl_akhir</b>";
                }
                ?>
            </center>

            <br>

            <table class="table table-bordered">

                <thead class="table-dark">
                    <tr>
                        <th>Tanggal</th>
                        <th>No Penjualan</th>
                        <th>Customer</th>
                        <th>Nama Barang</th>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>

                <tbody>

                <?php

                $where = "";

                if($tgl_awal != "" && $tgl_akhir != ""){
                    $where = "
                    WHERE p.tanggal_penjualan
                    BETWEEN '$tgl_awal'
                    AND '$tgl_akhir'
                    ";
                }

                $sql = $db->query("
                    SELECT
                        p.tanggal_penjualan,
                        p.no_penjualan,
                        c.nama_customer,
                        b.nama_barang,
                        d.jumlah_barang,
                        d.harga_barang,
                        d.total_harga
                    FROM detail_penjualan d

                    JOIN tb_penjualan p
                    ON d.no_penjualan = p.no_penjualan

                    JOIN tb_customer c
                    ON p.id_customer = c.id_customer

                    JOIN tb_barang b
                    ON d.kd_barang = b.kd_barang

                    $where

                    ORDER BY p.tanggal_penjualan DESC
                ");

                $grandtotal = 0;

                while($r = mysqli_fetch_assoc($sql)){

                    $grandtotal += $r['total_harga'];
                ?>

                    <tr>

                        <td><?= $r['tanggal_penjualan']; ?></td>

                        <td><?= $r['no_penjualan']; ?></td>

                        <td><?= $r['nama_customer']; ?></td>

                        <td><?= $r['nama_barang']; ?></td>

                        <td><?= $r['jumlah_barang']; ?></td>

                        <td align="right">
                            Rp <?= number_format($r['harga_barang'],0,',','.'); ?>
                        </td>

                        <td align="right">
                            Rp <?= number_format($r['total_harga'],0,',','.'); ?>
                        </td>

                    </tr>

                <?php } ?>

                <tr>

                    <th colspan="6" class="text-end">
                        TOTAL
                    </th>

                    <th>
                        Rp <?= number_format($grandtotal,0,',','.'); ?>
                    </th>

                </tr>

                </tbody>

            </table>

        </div>

    </div>
</div>

<style>

/* KHUSUS SAAT DICETAK */
@media print{

    .btn,
    form,
    .navbar,
    h3{
        display:none !important;
    }

    body{
        background:#fff;
        margin:30px;
        font-family:Arial, sans-serif;
        font-size:12px;
    }

    .card,
    .card-body{
        border:none !important;
        box-shadow:none !important;
        padding:0 !important;
    }

    /* Kop laporan */
    #print-area::before{
        content:"SISTEM INFORMASI STOK GUDANG\A LAPORAN TRANSAKSI PENJUALAN";
        white-space:pre;
        display:block;
        text-align:center;
        font-size:20px;
        font-weight:bold;
        border-bottom:3px solid black;
        padding-bottom:10px;
        margin-bottom:20px;
    }

    table{
        width:100%;
        border-collapse:collapse !important;
    }

    table th,
    table td{
        border:1px solid black !important;
        padding:8px !important;
    }

    table th{
        background:#dddddd !important;
        color:black !important;
        text-align:center;
    }

    /* Tanda tangan */
    #print-area::after{
        content:"\A\A\A Subang, " attr(data-tanggal) "\A\A Mengetahui,\A Admin Gudang\A\A\A\A\A(____________________)";
        white-space:pre;
        display:block;
        text-align:right;
        margin-top:50px;
        font-size:12px;
    }
}

</style>