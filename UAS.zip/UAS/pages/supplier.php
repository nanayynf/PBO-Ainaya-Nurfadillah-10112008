<?php
global $db;

if(isset($_GET['hapus'])){

    $id = $_GET['hapus'];

    $db->query("DELETE FROM tb_supplier WHERE id_supplier='$id'");

    echo "<script>
        alert('Supplier berhasil dihapus');
        window.location='?page=supplier';
    </script>";
}
?>

<div class="card shadow-sm">
    <div class="card-body">

        <h3 class="mb-4">Data Supplier</h3>

       <a href="?page=tambah_supplier"
   class="btn btn-primary mb-3 w-100">
    + Tambah Supplier
</a>

        <table class="table table-bordered table-striped">

            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Nama Supplier</th>
                    <th>Alamat</th>
                    <th>Telepon</th>
                    <th>Email</th>
                    <th width="180">Aksi</th>
                </tr>
            </thead>

            <tbody>

            <?php
            $no = 1;

            $data = $db->query("
                SELECT *
                FROM tb_supplier
                ORDER BY id_supplier DESC
            ");

            while($r = mysqli_fetch_assoc($data)){
            ?>

                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $r['nama_supplier']; ?></td>
                    <td><?= $r['alamat_supplier']; ?></td>
                    <td><?= $r['telepon_supplier']; ?></td>
                    <td><?= $r['email_supplier']; ?></td>

                    <td>
                        <a href="?page=edit_supplier&id=<?= $r['id_supplier']; ?>"
   class="btn btn-warning btn-sm">
   Edit
</a>
                        <a href="?page=supplier&hapus=<?= $r['id_supplier']; ?>"
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Yakin hapus supplier?')">
                            Hapus
                        </a>
                    </td>
                </tr>

            <?php } ?>

            </tbody>

        </table>

    </div>
</div>