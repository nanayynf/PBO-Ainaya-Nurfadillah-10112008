<?php
global $db;

if(isset($_POST['simpan'])){

    $no_pembelian = $_POST['no_pembelian'];
    $tanggal      = $_POST['tanggal'];
    $supplier     = $_POST['id_supplier'];

    $barang       = $_POST['kd_barang'];
    $jumlah       = $_POST['jumlah_barang'];

    $ambil = $db->query("
        SELECT *
        FROM tb_barang
        WHERE kd_barang='$barang'
    ");

    $b = mysqli_fetch_assoc($ambil);

    $kode_jenis = $b['kode_jenis'];
    $harga      = $b['harga_beli'];

    $total = $jumlah * $harga;

    // Header Pembelian
    $db->query("
        INSERT INTO tb_pembelian
        (
            no_pembelian,
            tanggal_pembelian,
            id_supplier,
            total_barangall,
            total_hargaall
        )
        VALUES
        (
            '$no_pembelian',
            '$tanggal',
            '$supplier',
            '$jumlah',
            '$total'
        )
    ");

    // Detail Pembelian
    $db->query("
        INSERT INTO detail_pembelian
        (
            no_pembelian,
            kd_barang,
            kode_jenis,
            jumlah_barang,
            harga_barang,
            total_harga
        )
        VALUES
        (
            '$no_pembelian',
            '$barang',
            '$kode_jenis',
            '$jumlah',
            '$harga',
            '$total'
        )
    ");

    // Update Stok
    $stok_baru = $b['stok'] + $jumlah;

    $db->query("
        UPDATE tb_barang
        SET stok='$stok_baru'
        WHERE kd_barang='$barang'
    ");

    echo "<script>
        alert('Pembelian berhasil disimpan');
        window.location='?page=pembelian';
    </script>";
}
?>

<div class="card shadow-sm p-4">

    <h3>Input Pembelian</h3>

    <form method="post">

        <div class="mb-3">
            <label>No Pembelian</label>
            <input type="text"
                   name="no_pembelian"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Tanggal</label>
            <input type="date"
                   name="tanggal"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Supplier</label>

            <select name="id_supplier"
                    class="form-control"
                    required>

                <option value="">Pilih Supplier</option>

                <?php
                $sup = $db->query("
                    SELECT *
                    FROM tb_supplier
                ");

                while($s = mysqli_fetch_assoc($sup)){
                ?>
                    <option value="<?= $s['id_supplier']; ?>">
                        <?= $s['nama_supplier']; ?>
                    </option>
                <?php } ?>

            </select>
        </div>

        <div class="mb-3">
            <label>Barang</label>

            <select name="kd_barang"
                    class="form-control"
                    required>

                <option value="">Pilih Barang</option>

                <?php
                $barang = $db->query("
                    SELECT *
                    FROM tb_barang
                ");

                while($b = mysqli_fetch_assoc($barang)){
                ?>
                    <option value="<?= $b['kd_barang']; ?>">
                        <?= $b['nama_barang']; ?>
                    </option>
                <?php } ?>

            </select>
        </div>

        <div class="mb-3">
            <label>Jumlah Barang</label>

            <input type="number"
                   name="jumlah_barang"
                   class="form-control"
                   required>
        </div>

        <button type="submit"
                name="simpan"
                class="btn btn-success">
            Simpan
        </button>

        <a href="?page=pembelian"
           class="btn btn-secondary">
            Kembali
        </a>

    </form>

</div>