<?php
global $db;

// Hapus Data
if(isset($_GET['hapus'])){

    $id = $_GET['hapus'];

    $db->query("
        DELETE FROM tb_barang
        WHERE kd_barang='$id'
    ");

    echo "<script>
        alert('Data berhasil dihapus');
        window.location='?page=barang';
    </script>";
}
?>

<div class="card shadow-sm">
    <div class="card-body">

        <h3 class="mb-4">Data Barang</h3>

        <a href="?page=tambah_barang" class="btn btn-primary mb-3 w-100">
    + Tambah Barang
</a>

        <div class="table-responsive">

            <table class="table table-bordered table-striped">

                <thead class="table-dark">
                    <tr>
                        <th width="60">No</th>
                        <th>Nama Barang</th>
                        <th>Satuan</th>
                        <th>Harga Modal</th>
                        <th width="180">Action</th>
                    </tr>
                </thead>

                <tbody>

                    <?php

                    $no = 1;

                    $data = $db->query("
                        SELECT
                            tb_barang.*,
                            tb_jenis.jenis,
                            tb_jenis.satuan
                        FROM tb_barang
                        LEFT JOIN tb_jenis
                        ON tb_barang.kode_jenis = tb_jenis.kode_jenis
                        ORDER BY tb_barang.nama_barang ASC
                    ");

                    while($r = mysqli_fetch_assoc($data)){
                    ?>

                    <tr>
                        <td><?= $no++; ?></td>

                        <td>
                            <?= $r['nama_barang']; ?>
                        </td>

                        <td>
                            <?= $r['satuan']; ?>
                        </td>

                        <td>
                            Rp <?= number_format($r['harga_beli'],0,',','.'); ?>
                        </td>

                        <td>
                            <a href="?page=edit_barang&id=<?= $r['kd_barang']; ?>"
                               class="btn btn-warning btn-sm">
                                Edit
                            </a>

                            <a href="?page=barang&hapus=<?= $r['kd_barang']; ?>"
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Yakin ingin menghapus data?')">
                                Hapus
                            </a>
                        </td>
                    </tr>

                    <?php } ?>

                </tbody>

            </table>

        </div>

    </div>
</div>