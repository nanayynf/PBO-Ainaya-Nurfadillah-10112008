<?php
global $db;

if(isset($_POST['simpan'])){

    $nama     = $_POST['nama_supplier'];
    $alamat   = $_POST['alamat_supplier'];
    $telepon  = $_POST['telepon_supplier'];
    $email    = $_POST['email_supplier'];
    $password = $_POST['pass_supplier'];

    $query = $db->query("
        INSERT INTO tb_supplier
        (
            nama_supplier,
            alamat_supplier,
            telepon_supplier,
            email_supplier,
            pass_supplier
        )
        VALUES
        (
            '$nama',
            '$alamat',
            '$telepon',
            '$email',
            '$password'
        )
    ");

    if($query){
        echo "<script>
            alert('Supplier berhasil ditambahkan');
            window.location='?page=supplier';
        </script>";
    }
}
?>

<div class="card shadow-sm p-4">

    <h3>Tambah Supplier</h3>

    <form method="post">

        <div class="mb-3">
            <label>Nama Supplier</label>
            <input type="text" name="nama_supplier" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Alamat</label>
            <textarea name="alamat_supplier" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
            <label>Telepon</label>
            <input type="text" name="telepon_supplier" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email_supplier" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Password</label>
            <input type="text" name="pass_supplier" class="form-control" required>
        </div>

        <button type="submit" name="simpan" class="btn btn-success">
            Simpan
        </button>

        <a href="?page=supplier" class="btn btn-secondary">
            Kembali
        </a>

    </form>

</div>