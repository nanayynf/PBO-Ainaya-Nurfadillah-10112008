<?php
global $db;
?>

<div class="card shadow-sm">
    <div class="card-body">

        <h3 class="mb-4">History Transaksi Pembelian</h3>
        
<a href="?page=tambah_pembelian"
   class="btn btn-primary mb-3 w-100">
   + Input Pembelian
</a>

        <table class="table table-bordered table-striped">
            
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>No Pembelian</th>
                    <th>Tanggal</th>
                    <th>Supplier</th>
                    <th>Total Barang</th>
                    <th>Total Harga</th>
                    <th>Detail</th>
                </tr>
            </thead>

            <tbody>

            <?php

            $no = 1;

            $data = $db->query("
                SELECT
                    p.*,
                    s.nama_supplier
                FROM tb_pembelian p
                LEFT JOIN tb_supplier s
                ON p.id_supplier = s.id_supplier
                ORDER BY p.no_pembelian DESC
            ");

            while($r = mysqli_fetch_assoc($data)){
            ?>

                <tr>

                    <td><?= $no++; ?></td>

                    <td><?= $r['no_pembelian']; ?></td>

                    <td><?= $r['tanggal_pembelian']; ?></td>

                    <td><?= $r['nama_supplier']; ?></td>

                    <td><?= $r['total_barangall']; ?></td>

                    <td>
                        Rp <?= number_format($r['total_hargaall'],0,',','.'); ?>
                    </td>

                    <td>

                        <a href="?page=detail_pembelian&id=<?= $r['no_pembelian']; ?>"
                           class="btn btn-info btn-sm">
                            Detail
                        </a>

                    </td>

                </tr>

            <?php } ?>

            </tbody>

        </table>

    </div>
</div>