<?php
global $db;

$id = $_GET['id'];

$data = $db->query("SELECT * FROM user WHERE id_user='$id'");
$r = mysqli_fetch_assoc($data);

if(isset($_POST['update'])){

    $username = $_POST['username'];
    $password = $_POST['password'];
    $tipe_user = $_POST['tipe_user'];

    $db->query("
        UPDATE user
        SET
            username='$username',
            password='$password',
            tipe_user='$tipe_user'
        WHERE id_user='$id'
    ");

    echo "<script>
        alert('User berhasil diupdate');
        window.location='?page=user';
    </script>";
}
?>

<div class="card shadow-sm p-4">

    <h3>Edit User</h3>

    <form method="post">

        <div class="mb-3">
            <label>Username</label>
            <input type="text"
                   name="username"
                   value="<?= $r['username']; ?>"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Password</label>
            <input type="text"
                   name="password"
                   value="<?= $r['password']; ?>"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Tipe User</label>
            <select name="tipe_user" class="form-control">

                <option value="Administrator"
                    <?= $r['tipe_user']=='Administrator'?'selected':''; ?>>
                    Administrator
                </option>

                <option value="Customer"
                    <?= $r['tipe_user']=='Customer'?'selected':''; ?>>
                    Customer
                </option>

                <option value="Supplier"
                    <?= $r['tipe_user']=='Supplier'?'selected':''; ?>>
                    Supplier
                </option>

            </select>
        </div>

        <button type="submit" name="update" class="btn btn-primary">
            Update
        </button>

        <a href="?page=user" class="btn btn-secondary">Kembali</a>

    </form>

</div>