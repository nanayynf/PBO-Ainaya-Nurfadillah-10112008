<?php
global $db;

if(isset($_POST['simpan'])){

    $username = $_POST['username'];
    $password = $_POST['password'];
    $tipe_user = $_POST['tipe_user'];

    $db->query("
        INSERT INTO user (username, password, tipe_user)
        VALUES ('$username', '$password', '$tipe_user')
    ");

    echo "<script>
        alert('User berhasil ditambahkan');
        window.location='?page=user';
    </script>";
}
?>

<div class="card shadow-sm p-4">

    <h3>Tambah User</h3>

    <form method="post">

        <div class="mb-3">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Password</label>
            <input type="text" name="password" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Tipe User</label>
            <select name="tipe_user" class="form-control" required>
                <option value="Administrator">Administrator</option>
                <option value="Customer">Customer</option>
                <option value="Supplier">Supplier</option>
            </select>
        </div>

        <button type="submit" name="simpan" class="btn btn-success">
            Simpan
        </button>

        <a href="?page=user" class="btn btn-secondary">Kembali</a>

    </form>

</div>