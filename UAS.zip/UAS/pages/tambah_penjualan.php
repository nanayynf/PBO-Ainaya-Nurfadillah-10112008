<?php
global $db;

if(isset($_POST['simpan'])){

    $no_penjualan = $_POST['no_penjualan'];
    $tanggal      = $_POST['tanggal'];
    $customer     = $_POST['id_customer'];

    $barang       = $_POST['kd_barang'];
    $jumlah       = $_POST['jumlah_barang'];

    // Ambil data barang
    $ambil = $db->query("
        SELECT *
        FROM tb_barang
        WHERE kd_barang='$barang'
    ");

    $b = mysqli_fetch_assoc($ambil);

    $stok_lama  = $b['stok'];
    $kode_jenis = $b['kode_jenis'];
    $harga      = $b['harga_jual'];

    // Cek stok
    if($jumlah > $stok_lama){

        echo "<script>
            alert('Stok barang tidak mencukupi!');
        </script>";

    } else {

        $total = $jumlah * $harga;

        // Simpan Header Penjualan
        $db->query("
            INSERT INTO tb_penjualan
            (
                no_penjualan,
                tanggal_penjualan,
                id_customer,
                total_barangall,
                total_hargaall
            )
            VALUES
            (
                '$no_penjualan',
                '$tanggal',
                '$customer',
                '$jumlah',
                '$total'
            )
        ");

        // Simpan Detail Penjualan
        $db->query("
            INSERT INTO detail_penjualan
            (
                no_penjualan,
                kd_barang,
                kode_jenis,
                jumlah_barang,
                harga_barang,
                total_harga
            )
            VALUES
            (
                '$no_penjualan',
                '$barang',
                '$kode_jenis',
                '$jumlah',
                '$harga',
                '$total'
            )
        ");

        // Kurangi stok
        $stok_baru = $stok_lama - $jumlah;

        $db->query("
            UPDATE tb_barang
            SET stok='$stok_baru'
            WHERE kd_barang='$barang'
        ");

        echo "<script>
            alert('Penjualan berhasil disimpan');
            window.location='?page=penjualan';
        </script>";
    }
}
?>

<div class="card shadow-sm p-4">

    <h3>Input Penjualan</h3>

    <form method="post">

        <div class="mb-3">
            <label>No Penjualan</label>
            <input type="text"
                   name="no_penjualan"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Tanggal</label>
            <input type="date"
                   name="tanggal"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Customer</label>

            <select name="id_customer"
                    class="form-control"
                    required>

                <option value="">Pilih Customer</option>

                <?php
                $cus = $db->query("
                    SELECT *
                    FROM tb_customer
                ");

                while($c = mysqli_fetch_assoc($cus)){
                ?>
                    <option value="<?= $c['id_customer']; ?>">
                        <?= $c['nama_customer']; ?>
                    </option>
                <?php } ?>

            </select>
        </div>

        <div class="mb-3">
            <label>Barang</label>

            <select name="kd_barang"
                    class="form-control"
                    required>

                <option value="">Pilih Barang</option>

                <?php
                $barang = $db->query("
                    SELECT *
                    FROM tb_barang
                ");

                while($b = mysqli_fetch_assoc($barang)){
                ?>
                    <option value="<?= $b['kd_barang']; ?>">
                        <?= $b['nama_barang']; ?>
                        (Stok : <?= $b['stok']; ?>)
                    </option>
                <?php } ?>

            </select>
        </div>

        <div class="mb-3">
            <label>Jumlah Barang</label>

            <input type="number"
                   name="jumlah_barang"
                   class="form-control"
                   required>
        </div>

        <button type="submit"
                name="simpan"
                class="btn btn-success">
            Simpan
        </button>

        <a href="?page=penjualan"
           class="btn btn-secondary">
            Kembali
        </a>

    </form>

</div>