<?php
// Gunakan global agar objek $db dari index.php terbaca
global $db;

// Logika Hapus Data
if(isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    // Sesuaikan query hapus untuk tb_barang
    $db->query("DELETE FROM tb_barang WHERE kd_barang = '$id'");
    echo "<script>alert('Data Berhasil Dihapus'); window.location='?page=gudang';</script>";
}
?>

<div class="card shadow-sm p-4">
    <h3>Data Gudang</h3>
    <a href="?page=tambah_barang" class="btn btn-primary mb-3">+ Tambah Barang</a>
    
    <table class="table table-bordered table-striped">
        <thead class="table-light">
            <tr>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Stok</th>
                <th>Harga Jual</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            // Memanggil data dari tb_barang
            $data = $db->query("SELECT * FROM tb_barang");
            while($r = mysqli_fetch_assoc($data)): ?>
            <tr>
                <td><?=$r['kd_barang']?></td>
                <td><?=$r['nama_barang']?></td>
                <td><?=$r['stok']?></td>
                <td><?=number_format($r['harga_jual'])?></td>
                <td>
                    <a href="?page=edit_barang&id=<?=$r['kd_barang']?>" class="btn btn-sm btn-info text-white">Edit</a>
                    <a href="?page=gudang&hapus=<?=$r['kd_barang']?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>