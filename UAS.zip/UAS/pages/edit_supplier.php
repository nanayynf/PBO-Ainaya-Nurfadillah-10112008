<?php
global $db;

$id = $_GET['id'];

$data = $db->query("
    SELECT *
    FROM tb_supplier
    WHERE id_supplier='$id'
");

$r = mysqli_fetch_assoc($data);

if(isset($_POST['update'])){

    $nama     = $_POST['nama_supplier'];
    $alamat   = $_POST['alamat_supplier'];
    $telepon  = $_POST['telepon_supplier'];
    $email    = $_POST['email_supplier'];
    $password = $_POST['pass_supplier'];

    $query = $db->query("
        UPDATE tb_supplier
        SET
            nama_supplier='$nama',
            alamat_supplier='$alamat',
            telepon_supplier='$telepon',
            email_supplier='$email',
            pass_supplier='$password'
        WHERE id_supplier='$id'
    ");

    if($query){

        echo "<script>
            alert('Data supplier berhasil diupdate');
            window.location='?page=supplier';
        </script>";

    } else {

        echo "<div class='alert alert-danger'>
                Gagal mengupdate data.
              </div>";

    }
}
?>

<div class="card shadow-sm p-4">

    <h3>Edit Supplier</h3>

    <form method="post">

        <div class="mb-3">
            <label>ID Supplier</label>
            <input type="text"
                   class="form-control"
                   value="<?= $r['id_supplier']; ?>"
                   readonly>
        </div>

        <div class="mb-3">
            <label>Nama Supplier</label>
            <input type="text"
                   name="nama_supplier"
                   value="<?= $r['nama_supplier']; ?>"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Alamat Supplier</label>
            <textarea name="alamat_supplier"
                      class="form-control"
                      required><?= $r['alamat_supplier']; ?></textarea>
        </div>

        <div class="mb-3">
            <label>Telepon Supplier</label>
            <input type="text"
                   name="telepon_supplier"
                   value="<?= $r['telepon_supplier']; ?>"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Email Supplier</label>
            <input type="email"
                   name="email_supplier"
                   value="<?= $r['email_supplier']; ?>"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Password Supplier</label>
            <input type="text"
                   name="pass_supplier"
                   value="<?= $r['pass_supplier']; ?>"
                   class="form-control"
                   required>
        </div>

        <button type="submit"
                name="update"
                class="btn btn-primary">
            Update
        </button>

        <a href="?page=supplier"
           class="btn btn-secondary">
            Kembali
        </a>

    </form>

</div>