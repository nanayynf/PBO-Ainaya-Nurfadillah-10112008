<?php
global $db;

if(isset($_POST['simpan'])){

    $nama     = $_POST['nama_customer'];
    $jk       = $_POST['jenis_kelamin'];
    $alamat   = $_POST['alamat_customer'];
    $telepon  = $_POST['telepon_customer'];
    $email    = $_POST['email_customer'];
    $password = $_POST['pass_customer'];

    $query = $db->query("
        INSERT INTO tb_customer
        (
            nama_customer,
            jenis_kelamin,
            alamat_customer,
            telepon_customer,
            email_customer,
            pass_customer
        )
        VALUES
        (
            '$nama',
            '$jk',
            '$alamat',
            '$telepon',
            '$email',
            '$password'
        )
    ");

    if($query){
        echo "<script>
            alert('Customer berhasil ditambahkan');
            window.location='?page=customer';
        </script>";
    }
}
?>

<div class="card shadow-sm p-4">

    <h3>Tambah Customer</h3>

    <form method="post">

        <div class="mb-3">
            <label>Nama Customer</label>
            <input type="text"
                   name="nama_customer"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin"
                    class="form-control"
                    required>
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Alamat</label>
            <textarea name="alamat_customer"
                      class="form-control"
                      required></textarea>
        </div>

        <div class="mb-3">
            <label>Telepon</label>
            <input type="text"
                   name="telepon_customer"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email"
                   name="email_customer"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Password</label>
            <input type="text"
                   name="pass_customer"
                   class="form-control"
                   required>
        </div>

        <button type="submit"
                name="simpan"
                class="btn btn-success">
            Simpan
        </button>

        <a href="?page=customer"
           class="btn btn-secondary">
            Kembali
        </a>

    </form>

</div>