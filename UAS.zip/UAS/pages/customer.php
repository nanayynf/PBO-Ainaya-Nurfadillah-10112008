<?php
global $db;

// Hapus Data
if(isset($_GET['hapus'])){

    $id = $_GET['hapus'];

    $db->query("
        DELETE FROM tb_customer
        WHERE id_customer='$id'
    ");

    echo "<script>
        alert('Customer berhasil dihapus');
        window.location='?page=customer';
    </script>";
}
?>

<div class="card shadow-sm">
    <div class="card-body">

        <h3 class="mb-4">Data Customer</h3>

        <a href="?page=tambah_customer"
   class="btn btn-primary mb-3 w-100">
    + Tambah Customer
</a>

        <div class="table-responsive">

            <table class="table table-bordered table-striped">

                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama Customer</th>
                        <th>Jenis Kelamin</th>
                        <th>Alamat</th>
                        <th>Telepon</th>
                        <th>Email</th>
                        <th width="180">Aksi</th>
                    </tr>
                </thead>

                <tbody>

                <?php

                $no = 1;

                $data = $db->query("
                    SELECT *
                    FROM tb_customer
                    ORDER BY id_customer DESC
                ");

                while($r = mysqli_fetch_assoc($data)){
                ?>

                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $r['nama_customer']; ?></td>
                        <td><?= $r['jenis_kelamin']; ?></td>
                        <td><?= $r['alamat_customer']; ?></td>
                        <td><?= $r['telepon_customer']; ?></td>
                        <td><?= $r['email_customer']; ?></td>

                        <td>
                            <a href="?page=edit_customer&id=<?= $r['id_customer']; ?>"
                               class="btn btn-warning btn-sm">
                                Edit
                            </a>

                            <a href="?page=customer&hapus=<?= $r['id_customer']; ?>"
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Yakin ingin menghapus customer?')">
                                Hapus
                            </a>
                        </td>
                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>
</div>