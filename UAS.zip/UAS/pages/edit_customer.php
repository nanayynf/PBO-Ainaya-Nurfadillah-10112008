<?php
global $db;

$id = $_GET['id'];

$data = $db->query("
    SELECT *
    FROM tb_customer
    WHERE id_customer='$id'
");

$r = mysqli_fetch_assoc($data);

if(isset($_POST['update'])){

    $nama     = $_POST['nama_customer'];
    $jk       = $_POST['jenis_kelamin'];
    $alamat   = $_POST['alamat_customer'];
    $telepon  = $_POST['telepon_customer'];
    $email    = $_POST['email_customer'];
    $password = $_POST['pass_customer'];

    $query = $db->query("
        UPDATE tb_customer
        SET
            nama_customer='$nama',
            jenis_kelamin='$jk',
            alamat_customer='$alamat',
            telepon_customer='$telepon',
            email_customer='$email',
            pass_customer='$password'
        WHERE id_customer='$id'
    ");

    if($query){
        echo "<script>
            alert('Customer berhasil diupdate');
            window.location='?page=customer';
        </script>";
    }
}
?>

<div class="card shadow-sm p-4">

    <h3>Edit Customer</h3>

    <form method="post">

        <div class="mb-3">
            <label>Nama Customer</label>
            <input type="text"
                   name="nama_customer"
                   value="<?= $r['nama_customer']; ?>"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin"
                    class="form-control">

                <option value="L"
                    <?= ($r['jenis_kelamin']=='L') ? 'selected' : ''; ?>>
                    Laki-laki
                </option>

                <option value="P"
                    <?= ($r['jenis_kelamin']=='P') ? 'selected' : ''; ?>>
                    Perempuan
                </option>

            </select>
        </div>

        <div class="mb-3">
            <label>Alamat</label>
            <textarea name="alamat_customer"
                      class="form-control"><?= $r['alamat_customer']; ?></textarea>
        </div>

        <div class="mb-3">
            <label>Telepon</label>
            <input type="text"
                   name="telepon_customer"
                   value="<?= $r['telepon_customer']; ?>"
                   class="form-control">
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email"
                   name="email_customer"
                   value="<?= $r['email_customer']; ?>"
                   class="form-control">
        </div>

        <div class="mb-3">
            <label>Password</label>
            <input type="text"
                   name="pass_customer"
                   value="<?= $r['pass_customer']; ?>"
                   class="form-control">
        </div>

        <button type="submit"
                name="update"
                class="btn btn-primary">
            Update
        </button>

        <a href="?page=customer"
           class="btn btn-secondary">
            Kembali
        </a>

    </form>

</div>