<?php
global $db;

$id = $_GET['id'];
?>

<div class="card shadow-sm">
    <div class="card-body">

        <h3 class="mb-4">
            Detail Penjualan #<?= $id ?>
        </h3>

        <a href="?page=penjualan"
           class="btn btn-secondary mb-3">
            Kembali
        </a>

        <table class="table table-bordered table-striped">

            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Kode Jenis</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Total</th>
                </tr>
            </thead>

            <tbody>

            <?php

            $no = 1;

            $data = $db->query("
                SELECT *
                FROM detail_penjualan
                WHERE no_penjualan='$id'
            ");

            while($r = mysqli_fetch_assoc($data)){
            ?>

                <tr>

                    <td><?= $no++; ?></td>

                    <td><?= $r['kd_barang']; ?></td>

                    <td><?= $r['kode_jenis']; ?></td>

                    <td><?= $r['jumlah_barang']; ?></td>

                    <td>
                        Rp <?= number_format($r['harga_barang'],0,',','.'); ?>
                    </td>

                    <td>
                        Rp <?= number_format($r['total_harga'],0,',','.'); ?>
                    </td>

                </tr>

            <?php } ?>

            </tbody>

        </table>

    </div>
</div>