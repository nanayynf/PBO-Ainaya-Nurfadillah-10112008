<?php
require_once 'Database.php';
$db = new Database();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Stok Gudang</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body{
            background:#fff0f5;
            font-family:'Segoe UI',sans-serif;
        }

        .navbar-custom{
            background:linear-gradient(90deg,#ff69b4,#ff85c1);
            box-shadow:0 3px 10px rgba(0,0,0,.15);
        }

        .navbar-custom .nav-link,
        .navbar-custom .dropdown-toggle{
            color:white !important;
            font-weight:bold;
        }

        .navbar-custom .dropdown-menu{
            background:#ff85c1;
            border:none;
        }

        .navbar-custom .dropdown-item{
            color:white;
        }

        .navbar-custom .dropdown-item:hover{
            background:#ff69b4;
        }

        .welcome-card{
            background:linear-gradient(135deg,#ff69b4,#ffc0cb);
            color:white;
            border:none;
            border-radius:20px;
        }

        .menu-card{
            border:none;
            border-radius:15px;
            transition:.3s;
            min-height:180px;
            box-shadow:0 4px 10px rgba(0,0,0,.1);
        }

        .menu-card:hover{
            transform:translateY(-5px);
            box-shadow:0 8px 20px rgba(0,0,0,.15);
        }

        .icon{
            font-size:55px;
            margin-bottom:10px;
        }

        .card-header{
            border-radius:15px 15px 0 0 !important;
            font-weight:bold;
        }

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container-fluid">

        <a class="navbar-brand text-white fw-bold" href="index.php">
             SI Gudang
        </a>

        <ul class="navbar-nav">

            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    Beranda
                </a>
            </li>

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle"
                   href="#"
                   data-bs-toggle="dropdown">
                    Kelola Data
                </a>

                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="?page=gudang">Data Gudang</a></li>
                    <li><a class="dropdown-item" href="?page=barang">Data Barang</a></li>
                    <li><a class="dropdown-item" href="?page=user">Data Pengguna</a></li>
                    <li><a class="dropdown-item" href="?page=customer">Data Customer</a></li>
                    <li><a class="dropdown-item" href="?page=supplier">Data Supplier</a></li>
                </ul>
            </li>

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle"
                   href="#"
                   data-bs-toggle="dropdown">
                    Kelola Transaksi
                </a>

                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="?page=pembelian">Transaksi Pembelian</a></li>
                    <li><a class="dropdown-item" href="?page=penjualan">Transaksi Penjualan</a></li>
                </ul>
            </li>

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle"
                   href="#"
                   data-bs-toggle="dropdown">
                    Kelola Laporan
                </a>

                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="?page=laporan_penjualan">Laporan Penjualan</a></li>
                </ul>
            </li>

        </ul>

    </div>
</nav>

<div class="container mt-4">

<?php

$page = $_GET['page'] ?? '';
$file = "pages/".$page.".php";

if($page != '' && file_exists($file)){

    include $file;

}else{

?>

    <!-- WELCOME -->
    <div class="card welcome-card p-5 text-center mb-4">

        <h1 class="fw-bold">
            🌸 Sistem Informasi Stok Gudang 🌸
        </h1>

        <h4 class="mt-3">
            Selamat Datang Admin
        </h4>

        <p>
            Kelola Data Barang, Kelola Transaksi, Kelola Laporan
        </p>

    </div>

    <!-- KELOLA DATA -->
    <div class="card mb-4">

        <div class="card-header bg-primary text-white">
            📂 Kelola Data
        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-md-4 mb-3">
                    <div class="card text-center p-3 menu-card">
                        <div class="icon">🏢</div>
                        <h5>Data Gudang</h5>
                        <a href="?page=gudang" class="btn btn-secondary">
                            Buka
                        </a>
                    </div>
                </div>

                <div class="col-md-4 mb-3">
                    <div class="card text-center p-3 menu-card">
                        <div class="icon">📦</div>
                        <h5>Data Barang</h5>
                        <a href="?page=barang" class="btn btn-primary">
                            Buka
                        </a>
                    </div>
                </div>

                <div class="col-md-4 mb-3">
                    <div class="card text-center p-3 menu-card">
                        <div class="icon">👨‍💼</div>
                        <h5>Data Pengguna</h5>
                        <a href="?page=user" class="btn btn-danger">
                            Buka
                        </a>
                    </div>
                </div>

                <div class="col-md-6 mb-3">
                    <div class="card text-center p-3 menu-card">
                        <div class="icon">👤</div>
                        <h5>Data Customer</h5>
                        <a href="?page=customer" class="btn btn-warning">
                            Buka
                        </a>
                    </div>
                </div>

                <div class="col-md-6 mb-3">
                    <div class="card text-center p-3 menu-card">
                        <div class="icon">🚚</div>
                        <h5>Data Supplier</h5>
                        <a href="?page=supplier" class="btn btn-success">
                            Buka
                        </a>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- KELOLA TRANSAKSI -->
    <div class="card mb-4">

        <div class="card-header bg-success text-white">
            🛒 Kelola Transaksi
        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-md-6 mb-3">
                    <div class="card text-center p-3 menu-card">
                        <div class="icon">📥</div>
                        <h5>Transaksi Pembelian</h5>
                        <a href="?page=pembelian" class="btn btn-success">
                            Buka
                        </a>
                    </div>
                </div>

                <div class="col-md-6 mb-3">
                    <div class="card text-center p-3 menu-card">
                        <div class="icon">📤</div>
                        <h5>Transaksi Penjualan</h5>
                        <a href="?page=penjualan" class="btn btn-primary">
                            Buka
                        </a>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- KELOLA LAPORAN -->
    <div class="card mb-4">

        <div class="card-header bg-dark text-white">
            📊 Kelola Laporan
        </div>

        <div class="card-body">

            <div class="card text-center p-4 menu-card">
                <div class="icon">🖨️</div>

                <h5>Laporan Penjualan</h5>

                <a href="?page=laporan_penjualan"
                   class="btn btn-dark">
                    Cetak Laporan
                </a>
            </div>

        </div>

    </div>

<?php
}
?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>