<?php
class Database {
    private $host = "localhost";
    private $user = "root";
    private $pass = "";
    private $db   = "db_inventory"; // Pastikan nama DB sesuai
    public $conn;

    public function __construct() {
        $this->conn = mysqli_connect($this->host, $this->user, $this->pass, $this->db);
    }
    
    public function query($sql) {
        return mysqli_query($this->conn, $sql);
    }
}
?>